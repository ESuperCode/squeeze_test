# Synthetic GitHub history demo

This package creates a **clearly labeled synthetic timeline**, not a rewritten
copy of the source contributors' actual Git history.

## Repositories

- Source: https://github.com/epsretriever/spherex-planet-x
- Destination: https://github.com/ESuperCode/squeeze_test
- Output branch: `synthetic-history`

The generated branch contains one synthetic commit per source commit and a
`timeline.csv` manifest. It does not copy source files or original contributor
identities. Source commit IDs and subjects are included as references.

## Install in the destination repository

Copy these two files to the destination repository's default branch:

- `synthetic_history_demo.py`
- `.github/workflows/synthetic-history.yml` (rename `synthetic-history.yml`
  to `squeeze.yml` if you prefer; the filename itself does not matter)

Enable Actions and set repository Actions permissions to allow read/write
contents. The workflow also declares the minimum required `contents: write`
permission for its `GITHUB_TOKEN`.

## Manual run and timeframe control

Open **Actions → Synthetic history demo → Run workflow**.

- `window_hours`: `24` is the default. Use `1`, `6`, `12`, `48`, `72`, `168`,
  or any positive number up to 87600.
- `start_utc`: optional ISO-8601 UTC timestamp such as
  `2026-01-01T00:00:00Z`. Leave blank to start at the current UTC time.

Every run rebuilds the synthetic branch from the complete current source
commit list and force-updates only `synthetic-history`. It does not force-push
to `main`.

## Push-triggered updates from the source

A destination workflow cannot directly subscribe to pushes in a different
repository. To trigger immediately when the source gets a push, you must have
permission to add `source-trigger/.github/workflows/notify-demo.yml` to the
source repository. Copy that file to the source repository as
`.github/workflows/notify-demo.yml`.

Then create a fine-grained GitHub token that has **Contents: write** access to
`ESuperCode/squeeze_test`, and add it to the source repository as the Actions
secret `SQUEEZE_DESTINATION_TOKEN`.

If you do not have write permission to the source repository, you cannot
install this source-side trigger. In that case, run the destination workflow
manually, or add scheduled polling to the destination workflow.

## Windows local preview

Install Git and Python 3.10+.

```powershell
py -3.11 -m pip install --upgrade pip
git --version
py -3.11 .\synthetic_history_demo.py `
  --source https://github.com/epsretriever/spherex-planet-x.git `
  --destination https://github.com/ESuperCode/squeeze_test.git `
  --window-hours 24
```

That command is preview-only. It does not publish anything. Change `24` to
another number to change the compression window. To publish locally, add
`--push` and authenticate Git to the destination repository first.

## Important notes

- The source repository remains untouched.
- The output branch is intentionally labeled synthetic.
- The synthetic author is `Synthetic Demo Bot`.
- GitHub push/event/audit timestamps remain actual publication times.
- Each run rebuilds the demo timeline; it does not preserve prior generated
  synthetic commit IDs.
- `push` mode requires write access to the source repo to install the
  source-side dispatch workflow. A public repo is not automatically writable.
